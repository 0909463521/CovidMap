import React from 'react';


import './App.css';

import CovidDashboard from "./components/CovidDashboard";

function App() {
    return (
        
        <CovidDashboard/>
        
    );
}

export default App;
